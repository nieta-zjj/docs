# CRPG

## 文档信息
- 类型：主题词条
- 更新日期：2026-02-22

## 定义
Computer Role-Playing Game，强调角色扮演、叙事分支、检定机制与规则系统的电子游戏类型。

## 相关词条
- [[00-元语/game]]
- [[00-元语/interactive-storytelling]]
- [[00-元语/design]]
- [[00-元语/decision-making]]

## 关联主题
- [[00-元语/game]]
- [[00-元语/interactive-storytelling]]
- [[00-元语/design]]
- [[00-元语/decision-making]]
