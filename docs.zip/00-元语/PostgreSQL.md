# PostgreSQL

## 文档信息

- 类型：元语词条
- 更新日期：2026-02-22

## 定义

PostgreSQL 是一种开源关系型数据库管理系统，常用于事务型业务、分析型查询与高可靠数据服务。

## 关联主题

- [[00-元语/context-database]]
- [[00-元语/ETL]]
- [[00-元语/data-pipeline]]
- [[00-元语/observability]]
- [[00-元语/self-hosting]]
