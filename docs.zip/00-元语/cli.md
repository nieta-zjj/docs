# cli

## 文档信息

- 类型：元语词条
- 更新日期：2026-02-22

## 定义

cli 指命令行界面（Command Line Interface），用于通过终端命令与程序交互。

## 相关词条

- [[00-元语/terminal]]
- [[00-元语/sdk]]
- [[00-元语/tool]]

## 关联主题

- [[00-元语/terminal]]
- [[00-元语/tool]]
- [[00-元语/workflow]]
- [[00-元语/productivity]]
- [[00-元语/security]]
