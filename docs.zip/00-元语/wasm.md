# wasm

## 文档信息

- 类型：元语词条
- 更新日期：2026-02-22

## 定义

wasm（WebAssembly）是一种可移植的二进制执行格式，常用于高性能跨平台运行。

## 核心内涵

WebAssembly 提供了一种接近原生执行速度的沙箱化运行环境。它不仅是 C/C++、Rust、Go 等高级语言的编译目标，还打破了传统 Web 开发中 JavaScript 的性能瓶颈。随着 WASI（WebAssembly System Interface）的发展，Wasm 的应用场景已从浏览器扩展至边缘计算、微服务和插件系统，成为一种轻量级、高安全性的通用计算抽象层。

## 实践要点

- 识别系统中的计算密集型任务（如图像处理、音视频编解码、复杂物理模拟），将其卸载至 Wasm 模块以提升性能。
- 妥善处理宿主环境与 Wasm 模块之间的内存边界，减少不必要的数据拷贝开销。
- 关注 Wasm 模块的体积优化，利用死代码消除和压缩工具加快网络加载与实例化速度。
- 严格限制 Wasm 模块的系统访问权限，确保沙箱环境的隔离性与安全性。

## 相关词条

- [[00-元语/browser-automation]]
- [[00-元语/serverless]]
- [[00-元语/cloudflare]]

## 关联主题

- [[00-元语/serverless]]
- [[00-元语/cloudflare]]
- [[00-元语/virtual-file-system]]
- [[00-元语/protocol]]
- [[00-元语/benchmark]]
- [[00-元语/security]]
