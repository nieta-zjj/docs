# virtual-file-system

## 文档信息

- 类型：元语词条
- 更新日期：2026-02-22

## 定义

virtual-file-system 指将底层存储抽象为统一文件系统接口的机制，便于挂载、迁移与审计。

## 相关词条

- [[00-元语/context-database]]
- [[00-元语/Agent]]
- [[00-元语/tool]]

## 关联主题
- [[00-元语/context-database]]
- [[00-元语/mcp]]
- [[00-元语/protocol]]
- [[00-元语/security]]
- [[00-元语/compliance]]
- [[00-元语/tool]]
