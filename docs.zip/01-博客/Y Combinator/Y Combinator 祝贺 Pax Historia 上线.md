# Y Combinator 祝贺 Pax Historia 上线

## 文档信息

- 发布日期：2026-02-06
- 作者：Y Combinator
- 来源：
  - https://x.com/ycombinator/status/2019810821032047046?s=46
  - https://ycombinator.com/launches/PMu-p
- 抓取时浏览量：982.7K Views

## 摘要

Y Combinator 宣布由 @Eli_BullockPapa 和 @Ryzhang22 开发的首款 AI 驱动沙盒游戏 Pax Historia 成功上线。

- Pax Historia 被描述为首款由 AI 驱动的沙盒游戏。
- 玩家可以在游戏中创造世界，并将其分享至社区。
- 核心体验是通过游玩探索各种“如果……会怎样”的设想。
- Y Combinator 在 X 上公开祝贺两位开发者上线新作。

## 正文

Pax Historia 是首款由 AI 驱动的沙盒游戏。

玩家可以创造世界，将其分享至社区，并在游玩中探索各种“如果……会怎样”的设想。

Y Combinator 在原帖中祝贺 @Eli_BullockPapa 和 @Ryzhang22 成功上线。

- 原帖链接：https://x.com/ycombinator/status/2019810821032047046?s=46
- 帖子内链接：https://t.co/VQiYOBcEDR
- 视频缩略图：https://pbs.twimg.com/amplify_video_thumb/2019790322990284800/img/Qk81-MHEHZuEXZTE.jpg

## 关联主题

- [[00-元语/AI]]
- [[00-元语/game]]
- [[00-元语/community]]
- [[00-元语/x]]
